import axios from "axios";

// For Vite: Use import.meta.env instead of process.env
const API_BASE_URL =
  import.meta.env.VITE_API_URL || "http://localhost:5000/api";

console.log("Contacts API Base URL:", API_BASE_URL);

// Create axios instance with auth token
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    console.error("Request Interceptor Error:", error);
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error("Axios Error Details:", {
      message: error.message,
      code: error.code,
      status: error.response?.status,
      statusText: error.response?.statusText,
      data: error.response?.data,
      url: error.config?.url,
      method: error.config?.method,
    });

    if (error.response?.status === 401) {
      // Handle unauthorized - redirect to login
      localStorage.removeItem("token");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

const contactsAPI = {
  // Get all contacts with optional filters
  getContacts: async (params = {}) => {
    try {
      console.log("Fetching contacts with params:", params);
      const response = await api.get("/contacts", { params });
      return response.data;
    } catch (error) {
      console.error("Error fetching contacts:", error);
      throw error;
    }
  },

  // Get single contact by ID
  getContactById: async (id) => {
    try {
      const response = await api.get(`/contacts/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching contact ${id}:`, error);
      throw error;
    }
  },

  // Create new contact
  createContact: async (contactData) => {
    try {
      console.log("Creating contact with data:", contactData);
      const response = await api.post("/contacts", contactData);
      console.log("Create contact response:", response.data);
      return response.data;
    } catch (error) {
      console.error("Error creating contact:", {
        error: error.message,
        response: error.response?.data,
        status: error.response?.status,
      });
      throw error;
    }
  },

  // Update contact
  updateContact: async (id, contactData) => {
    try {
      console.log(`Updating contact ${id}:`, contactData);

      if (!id || id === "undefined" || id === "null") {
        throw new Error("Invalid contact ID");
      }

      // Clean the data - remove empty fields
      const cleanData = { ...contactData };
      Object.keys(cleanData).forEach((key) => {
        if (cleanData[key] === "" && key !== "email" && key !== "phone") {
          delete cleanData[key];
        }
      });

      console.log("Cleaned data for update:", cleanData);

      const response = await api.put(`/contacts/${id}`, cleanData);
      console.log("Update response:", response.data);
      return response.data;
    } catch (error) {
      console.error(`Error updating contact ${id}:`, {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        url: error.config?.url,
      });
      throw error;
    }
  },

  // Delete contact
  deleteContact: async (id) => {
    try {
      const response = await api.delete(`/contacts/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error deleting contact ${id}:`, error);
      throw error;
    }
  },

  // Bulk update contacts
  bulkUpdateContacts: async (contactIds, updates) => {
    try {
      const response = await api.put("/contacts/bulk/update", {
        contactIds,
        updates,
      });
      return response.data;
    } catch (error) {
      console.error("Error bulk updating contacts:", error);
      throw error;
    }
  },

  // Bulk delete contacts
  bulkDeleteContacts: async (contactIds) => {
    try {
      const response = await api.delete("/contacts/bulk/delete", {
        data: { contactIds },
      });
      return response.data;
    } catch (error) {
      console.error("Error bulk deleting contacts:", error);
      throw error;
    }
  },

  // Get filter options
  getFilterOptions: async () => {
    try {
      const response = await api.get("/contacts", { params: { limit: 1 } });
      return response.data.filters || {};
    } catch (error) {
      console.error("Error fetching filter options:", error);
      return { accounts: [], departments: [], leadSources: [] };
    }
  },

  // UPDATED: Export contacts - using frontend export for now
  exportContacts: async (format = "csv", filters = {}) => {
    try {
      console.log(
        "API: Exporting contacts with format:",
        format,
        "filters:",
        filters
      );

      // Clean filters - remove "all" values
      const cleanFilters = {};
      Object.keys(filters).forEach((key) => {
        if (
          filters[key] &&
          filters[key] !== "all" &&
          filters[key] !== "no-change"
        ) {
          // Handle contactIds specially
          if (
            key === "contactIds" &&
            Array.isArray(filters[key]) &&
            filters[key].length > 0
          ) {
            cleanFilters.contactIds = filters[key];
          } else if (key !== "contactIds") {
            cleanFilters[key] = filters[key];
          }
        }
      });

      // Get all contacts with filters
      const params = {
        ...cleanFilters,
        limit: 10000, // Get all contacts
        page: 1,
        sortBy: "createdAt",
        sortOrder: "desc",
      };

      console.log("Fetching contacts for export with params:", params);

      const response = await api.get("/contacts", { params });
      const contacts = response.data.contacts || [];

      console.log(`Fetched ${contacts.length} contacts for export`);

      // Return the contacts data - the contactsService will handle the actual export
      return {
        success: true,
        data: contacts,
        message: `Found ${contacts.length} contacts for export`,
      };
    } catch (error) {
      console.error("API Error exporting contacts:", error);
      throw error;
    }
  },

  // Search contacts
  searchContacts: async (query, limit = 10) => {
    try {
      const response = await api.get("/contacts", {
        params: { search: query, limit },
      });
      return response.data;
    } catch (error) {
      console.error("Error searching contacts:", error);
      throw error;
    }
  },

  // Get filter values
  getFilterValues: async () => {
    try {
      const response = await api.get("/contacts");
      return {
        success: true,
        data: response.data.filters || {},
      };
    } catch (error) {
      console.error("Error getting filter values:", error);
      throw error;
    }
  },

  // Get contact stats
  getContactStats: async () => {
    try {
      // For now, get stats from the contacts endpoint
      const response = await api.get("/contacts", { params: { limit: 1 } });
      return {
        success: true,
        data: {
          total: response.data.total || 0,
          stats: response.data.stats || {},
        },
      };
    } catch (error) {
      console.error("Error getting contact stats:", error);
      throw error;
    }
  },

  // Convert lead to contact
  convertLeadToContact: async (
    leadData,
    accountData = null,
    dealData = null
  ) => {
    try {
      const response = await api.post("/contacts/convert-from-lead", {
        leadData,
        accountData,
        dealData,
      });
      return response.data;
    } catch (error) {
      console.error("Error converting lead to contact:", error);
      throw error;
    }
  },

  // Sync contact from lead
  syncContactFromLead: async (contactId, leadData) => {
    try {
      const response = await api.put(
        `/contacts/${contactId}/sync-from-lead`,
        leadData
      );
      return response.data;
    } catch (error) {
      console.error("Error syncing contact from lead:", error);
      throw error;
    }
  },

  // Merge contacts
  mergeContacts: async (
    primaryContactId,
    duplicateContactIds,
    mergeFields = {}
  ) => {
    try {
      const response = await api.post("/contacts/merge", {
        primaryContactId,
        duplicateContactIds,
        mergeFields,
      });
      return response.data;
    } catch (error) {
      console.error("Error merging contacts:", error);
      throw error;
    }
  },

  // Import contacts
  importContacts: async (contacts, overwrite = false) => {
    try {
      const response = await api.post("/contacts/import", {
        contacts,
        overwrite,
      });
      return response.data;
    } catch (error) {
      console.error("Error importing contacts:", error);
      throw error;
    }
  },

  // Get all contacts (alias for getContacts)
  getAllContacts: async (params = {}) => {
    return contactsAPI.getContacts(params);
  },
};

export default contactsAPI;
