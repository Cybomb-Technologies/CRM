import React from "react";
import Sidebar from "../../../components/files/sales/documents/Sidebar";
import TopBar from "../../../components/files/sales/documents/TopBar";
import EmptyState from "../../../components/files/sales/documents/EmptyState";
import DocumentList from "../../../components/files/sales/documents/DocumentList";
import { documentsAPI } from "../../../components/files/sales/documents/documentsAPI";
const DocumentPage = () => {
  const [documents, setDocuments] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const fetchDocuments = async () => {
    try {
      setIsLoading(true);
      const data = await documentsAPI.getDocuments();
      setDocuments(data);
    } catch (error) {
      console.error("Failed to fetch documents:", error);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchDocuments();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this document?")) {
      try {
        await documentsAPI.deleteDocument(id);
        fetchDocuments(); // Refresh list
      } catch (error) {
        console.error("Failed to delete document:", error);
      }
    }
  };

  return (
    <div className="flex h-screen bg-white overflow-hidden">
      {/* LEFT SIDEBAR */}
      <Sidebar />

      {/* RIGHT MAIN AREA */}
      <div className="flex-1 flex flex-col border-l border-gray-300">
        {/* TOP BAR */}
        <TopBar onUploadSuccess={fetchDocuments} />

        {/* MAIN CONTENT */}
        <div className="flex-1 bg-white overflow-auto p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">Loading...</div>
          ) : documents.length > 0 ? (
            <DocumentList documents={documents} onDelete={handleDelete} />
          ) : (
            <EmptyState onUploadSuccess={fetchDocuments} />
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentPage;
